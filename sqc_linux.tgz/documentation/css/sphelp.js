window.onload= resizeSplitWndw;
window.onresize= resizeSplitWndw;
window.onbeforeprint= set_to_print;
window.onafterprint= reset_form;

function resizeSplitWndw()
{
	var onsr = document.all.item("nsr");
	var omainbody = document.all.item("content");

	if (omainbody ==null) 
		return;

	if (onsr != null)
	{
		document.all.content.style.overflow= "auto";
		document.all.nsr.style.width= document.body.offsetWidth;
		document.all.content.style.width= document.body.offsetWidth;
		document.all.content.style.top= document.all.nsr.offsetHeight;
		if (document.body.offsetHeight > document.all.nsr.offsetHeight)
		{
			document.all.content.style.height= document.body.offsetHeight - document.all.nsr.offsetHeight - 3;
		}
		else 
		{
			document.all.content.style.height=0;
		}
	}
}

function set_to_print()
{
	var i;
	if (window.content)
	{
		document.all.content.style.height = "auto";
	}

	for (i=0; i < document.all.length; i++)
	{
		if (document.all[i].tagName == "BODY") 
		{
			document.all[i].scroll = "auto";
		}
		if (document.all[i].tagName == "A") 
		{
			document.all[i].outerHTML = "<a href=''>" + document.all[i].innerHTML + "</a>";
		}
	}
}

function reset_form()
{
	document.location.reload();
}